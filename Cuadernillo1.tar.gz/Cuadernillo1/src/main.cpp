//============================================================================
// Name        : main.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "TCalendario.h"
using namespace std;

int main() {
	char *c = new char[250];
	c =  "adios";
	TCalendario TCal(31,12,1990,c);
	TCal + 31;
	cout << TCal<<endl;
	TCalendario TCal2;

	TCal2 = TCal;
	cout << TCal2<<endl;

	TCal++;
	cout << TCal<<endl;
	TCal--;
	TCal--;
	cout << TCal<<endl;
	return 0;
}

