//============================================================================
// Name        : TCalendario.cpp
// Author      : Daniel Siguenza Rico
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "TCalendario.h"
using namespace std;

TCalendario::TCalendario ()
{
	this->dia = 1;
	this->mes = 1;
	this->anyo = 1900;
	mensaje = NULL;
}
TCalendario::TCalendario(int dia, int mes, int anyo, char *mens)
{
	bool fechOk = true;

	int diaMax = compruebaFecha(mes,anyo);

	if(dia>diaMax || dia<1) // EL DIA NO ES CORRECTO
		fechOk = false;
	if(mes>12 || mes<1) // EL MES NO ES CORRECTO
		fechOk = false;
	if(anyo<1900)	// EL ANYO NO ES CORRECTO
		fechOk = false;

	if(!fechOk)	// Si la fecha no es correcta, poner por defecto
	{
		this->dia = 1;
		this->mes = 1;
		this->anyo = 1900;
		this->mensaje =  new char[strlen(mens)+1];
		this->mensaje = NULL;
	}
	else
	{
		this->dia = dia;
		this->mes = mes;
		this->anyo = anyo;
		if(mens!=NULL)
		{
			this->mensaje =  new char[strlen(mens)+1];
			strcpy(this->mensaje,mens);
		}
	}
}

//Constructor copia
TCalendario::TCalendario (const TCalendario &TCal)
{
	this->dia=TCal.dia;
	this->mes=TCal.mes;
	this->anyo=TCal.anyo;
	this->mensaje=TCal.mensaje;

}

// METODO PRIVADO QUE COMPRUEBA SI LA FECHA ES CORRECTA
int TCalendario::compruebaFecha(int mes, int anyo)
{
	int diaMax;

	if(mes==1 || mes==3 || mes==5 || mes==7 || mes==8 || mes==10 || mes==12)
	{
		diaMax = 31;
	}
	else if(mes==4 || mes==6 || mes==9 || mes==11)
	{
		diaMax = 30;
	}
	else if(mes == 2)
	{
		if((anyo%4 == 0) && ((anyo%100 !=0) || (anyo%400 == 0)))
		{
			diaMax = 29;
		}
		else
		{
			diaMax = 28;
		}
	}
	else
	{
		diaMax = 31; // Suponemos el mes Enero por defecto
	}

	return diaMax;
}

TCalendario::~TCalendario()
{
	dia = 1;
	mes = 1;
	anyo = 1900;
	mensaje = NULL;
}

// Sobrecarga del operador asignación
TCalendario& TCalendario:: operator=(TCalendario &t)
{

	if (this != &t)
	{
		(*this).~TCalendario();
		this->dia=t.dia;
		this->mes=t.mes;
		this->anyo=t.anyo;
		this->mensaje=t.mensaje;
	}

	return *this;
}

// Sobrecarga del operador SUMA de fecha + un número de dias;
TCalendario& TCalendario:: operator+(const int n)
{
	int diaMax = compruebaFecha(mes,anyo);
	// HACER OBJETO TEMPORAL
	if((dia+n)>diaMax)
	{
		dia = (dia+n)-diaMax;
		mes = mes+1;

		if(mes>12)
		{
			mes=1;
			anyo = anyo+1;
		}
	}
	else
	{
		dia = dia+n;
	}

	return *this;
}

// Sobrecarga del operador RESTA de fecha - un número de dias;
TCalendario& TCalendario:: operator-(const int n)
{
	int diaMax = compruebaFecha(mes,anyo);
	// HACER OBJETO TEMPORAL
	if((dia-n)<1)
	{
		dia = (dia-n)+diaMax;
		mes = mes-1;

		if(mes<1)
		{
			mes=12;
			anyo = anyo-1;
		}
	}
	else
	{
		dia = dia-n;
	}

	return *this;
}

// Modifica la fecha incrementandola en un dia (con postincremento);
TCalendario TCalendario:: operator++(int t)
{
	TCalendario tC(*this); // OBJETO TEMPORAL

	*this + 1;
	return tC;
}

// Modifica la fecha incrementandola en un dia (con preincremento);
TCalendario& TCalendario:: operator++(void)
{
	*this + 1;
	return *this;
}

// Modifica la fecha decrementándola en un dia (con postdecremento);
TCalendario TCalendario:: operator--(int t)
{
	TCalendario tC(*this); // OBJETO TEMPORAL

	*this - 1;
	return tC;
}

// Modifica la fecha decrementándola en un día (con predecremento);
TCalendario& TCalendario:: operator--(void)
{
	*this - 1;
	return *this;
}

// Modifica la fecha
bool TCalendario::ModFecha (int dia, int mes, int anyo)
{
	bool ok = true;
	int diaMax = compruebaFecha(mes,anyo); // DEVUELVE EL DIA MAXIMO QUE TIENE EL MES
	if(!((dia>diaMax || dia<1)||(mes<1 || mes>12) || (anyo<1900))) // LA FECHA ES CORRECTA
	{
		this->dia = dia;
		this->mes=mes;
		this->anyo=anyo;
	}
	else
	{
		ok = false;
	}

	return ok;
}

// Modifica el mensaje
bool ModMensaje(char *);

bool TCalendario::compara(TCalendario t)
{
	bool ok = false;

	// FALTA COMPARAR MENSAJE
	if((t.dia==dia) && (t.mes==mes) && (t.anyo==anyo))
		ok = true;
	else
		ok = false;

	return ok;
}

// Sobrecarga del operador igualdad;
bool TCalendario::operator ==(const TCalendario &t)
{
	return compara(t);
}

// Sobrecarga del operador desigualdad;
bool TCalendario::operator !=(const TCalendario &t)
{
	return !(compara(t));
}

// Devuelve el día del calendario;
int TCalendario::Dia()
{
	return dia;
}

int TCalendario::Mes()
{
	return mes;
}

int TCalendario::Anyo()
{
	return anyo;
}

// NO FUNCIONA BIEN
char* TCalendario::Mensaje()
{
	return mensaje;
}

ostream&  operator<<(ostream &s,const TCalendario &obj)
{
	s << obj.dia<<"/";
	s << obj.mes<<"/";
	s << obj.anyo<<" ";
	s << " " << obj.mensaje;
	return s;
}
